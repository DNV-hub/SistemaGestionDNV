// Prueba: sin caché. Este SW se desinstala solo y limpia lo guardado por versiones anteriores.
self.addEventListener('install', () => self.skipWaiting())
self.addEventListener('activate', (e) => e.waitUntil((async () => {
  for (const k of await caches.keys()) await caches.delete(k)
  await self.registration.unregister()
  const cs = await self.clients.matchAll({ type: 'window' })
  cs.forEach((c) => c.navigate(c.url))
})()))
